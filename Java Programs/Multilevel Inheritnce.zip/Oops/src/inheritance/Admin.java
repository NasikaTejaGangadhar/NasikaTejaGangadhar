package inheritance;

public class Admin extends Developer{
	public void manage() {
		System.out.println("manage code");
	}

}
