package inheritance;

public class Developer extends Guest{
	public void write( ) {
		System.out.println("write code");
	}

}
