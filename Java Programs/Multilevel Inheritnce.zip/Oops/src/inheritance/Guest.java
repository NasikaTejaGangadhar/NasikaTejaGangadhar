package inheritance;

public class Guest {
	public void read() {
		System.out.println("Read code ");
	}
}
